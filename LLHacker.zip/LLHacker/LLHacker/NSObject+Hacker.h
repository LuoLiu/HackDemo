//
//  NSObject+Hacker.h
//  LLHacker
//
//  Created by luoliu on 2018/5/15.
//  Copyright © 2018年 ll. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSObject (Hacker)

- (void)hack;

@end
