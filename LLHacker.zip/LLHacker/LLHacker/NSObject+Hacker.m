//
//  NSObject+Hacker.m
//  LLHacker
//
//  Created by luoliu on 2018/5/15.
//  Copyright © 2018年 ll. All rights reserved.
//

#import "NSObject+Hacker.h"
#import <objc/runtime.h>

@implementation NSObject (Hacker)

- (void)hack {
    NSString *className = @"ViewController";
    Class selfClass = [self class];
    [self swizzlingMethod:@"testText" ofClass:className toMethod:@selector(ll_testText) ofClass:selfClass isInstanceMethod:YES];
}

- (NSString *)ll_testText {
    NSLog(@">>>>>>>> ll_testText");
    NSString *text = [self ll_testText];
    NSLog(@">>>>>>>> ll_testText text: %@", text);
    text = @"hack_text";
    NSLog(@">>>>>>>> change testText to text: %@", text);
    return text;
}

// Method Swizzling
- (void)swizzlingMethod:(NSString *)methodName ofClass:(NSString *)className toMethod:(SEL)method ofClass:(Class)class isInstanceMethod:(BOOL)isInstanceMethod {
    Class originClass = NSClassFromString(className);
    SEL originSel = NSSelectorFromString(methodName);
    Method originMethod = isInstanceMethod ? class_getInstanceMethod(originClass, originSel) : class_getClassMethod(originClass, originSel);
    Method customMethod = isInstanceMethod ? class_getInstanceMethod(class, method) : class_getClassMethod(class, method);
    method_exchangeImplementations(originMethod, customMethod);
}

@end
