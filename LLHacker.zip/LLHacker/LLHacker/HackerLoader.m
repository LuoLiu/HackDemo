//
//  HackerLoader.m
//  LLHacker
//
//  Created by luoliu on 2018/5/15.
//  Copyright © 2018年 ll. All rights reserved.
//

#import "HackerLoader.h"
#import "NSObject+Hacker.h"

@implementation HackerLoader

static void __attribute__((constructor)) hackEntry(void) {
    NSLog(@">>>>>>> Code Injected <<<<<<<");
    NSObject *obj = [[NSObject alloc] init];
    [obj hack];
}

@end
